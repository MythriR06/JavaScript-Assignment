function doSomething(){
     let name=document.querySelector("#inp").value;
     let city=document.querySelector("#cit").value;
    document.querySelector("#sec").innerHTML=`<h1>${name} ${city}</h1>`;
}